package bolao;
public class Bolao {
    public static void main(String[] args) {
        Sistema sis = new Sistema();
        sis.sorteio();
        }
}
