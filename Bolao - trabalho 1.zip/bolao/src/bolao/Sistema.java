package bolao;
import java.util.Scanner;
class Sistema {
    private Aposta a;

    Sistema() {
        this.a = new Aposta();
    }
    public void sorteio() {

        int[] nums = new int[6];
        Scanner s = new Scanner(System.in);

        System.out.println("Qual o número sorteado?: ");
        nums[0] = s.nextInt();
        System.out.println("Qual o número sorteado?: ");
        nums[1] = s.nextInt();
        System.out.println("Qual o número sorteado?: ");
        nums[2] = s.nextInt();
        System.out.println("Qual o número sorteado?: ");
        nums[3] = s.nextInt();
        System.out.println("Qual o número sorteado?: ");
        nums[4] = s.nextInt();
        System.out.println("Qual o número sorteado?: ");
        nums[5] = s.nextInt();

        System.out.println("Valor total: ");
        double valor = s.nextDouble();

        if (a.vencedora(nums)) {
            a.exibirPremio(valor);
        }
        else {
            System.out.println("PERDEU");
        }
    }
}

