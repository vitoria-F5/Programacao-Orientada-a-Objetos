package bolao;
import java.util.Scanner;
public class Aposta {

    private Jogador organizador;
    private Jogador jog1;
    private Jogador jog2;
    private int n;
    private int[] numeros;

    public Aposta() {

        Scanner s = new Scanner(System.in);

        System.out.println("Digite a quantidade de números que vai apostar: ");
        this.n = s.nextInt();

        numeros = new int[n];

        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Digite a sua aposta: ");
            numeros[i] = s.nextInt();
        }
        this.organizador = new Jogador();
        this.jog1 = new Jogador();
        this.jog2 = new Jogador();
    }

    public boolean vencedora(int[] sorteados) {

        int contador = 0;
        System.out.println(this.n);
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < 6; j++) {
                if (numeros[i] == sorteados[j]) {
                    contador += 1;
                }
            }
        }
        if (contador == 6) {
            return true;
        }
        else {
            return false;
        }
    }

    public void exibirPremio(Double valor) {
        organizador.listarDados();
        System.out.println("Prêmio: " + ((0.1 * valor) + (0.30 * valor)));

        jog1.listarDados();
        System.out.println("Prêmio: " + ((0.30) * valor));

        jog2.listarDados();
        System.out.println("Prêmio: " + ((0.30) * valor));
    }
}
