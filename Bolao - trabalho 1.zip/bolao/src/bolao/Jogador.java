package bolao;
import java.util.Scanner;
class Jogador extends Pessoa {

    private String pix;

    Jogador() {
        super();
        Scanner s = new Scanner(System.in);

        System.out.println("Digite o seu pix: ");
        this.pix = s.nextLine();
    }
    public void listarDados() {
        super.listarDados();
        System.out.println("PIX: " + this.pix);
    }
}