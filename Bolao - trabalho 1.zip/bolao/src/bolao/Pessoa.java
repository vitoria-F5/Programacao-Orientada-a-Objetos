package bolao;
import java.util.Scanner;
public class Pessoa {

    protected String nome;
    protected String cpf;

    Pessoa() {
        Scanner s = new Scanner(System.in);

        System.out.println("Dígite o nome, por favor!: ");
        this.nome = s.nextLine();
        System.out.println("Dígite o cpf: ");
        this.cpf = s.nextLine();
    }

    public void listarDados() {
        System.out.println("Nome: " + this.nome);
        System.out.println("CPF: " + this.cpf);
    }
}
